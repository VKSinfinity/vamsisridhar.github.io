# Vamsi Sridhar
# Pizza
# 25/2/17

my_menu = open("Menu.txt", mode="r", encoding="utf-8")
order = []


def filetolist(line):
    line = line[:-4]
    line = line[2:]
    line = line.split(";")
    return line


crust = filetolist(str(my_menu.readlines(1)))
size = filetolist(str(my_menu.readlines(2)))
base = filetolist(str(my_menu.readlines(3)))
nonveg = filetolist(str(my_menu.readlines(4)))
veg = filetolist(str(my_menu.readlines(5)))


def printArray(menulist):
    count = 0
    for i in menulist:
        count += 1
        print(str(count)+") "+i)


def money(choice):
    price = choice.split(":")[1]
    price = price.replace(" ", "")
    return price


def validate(choice,whichdef, array, total):
    if choice.isdigit():
        if len(array) >= int(choice) >= 1:
            return choice
        else:
            if whichdef == "crust":
                crustdf(total)
            elif whichdef == "size":
                sizedf(total)
            elif whichdef == "base":
                basedf(total)
            elif whichdef == "toppings":
                toppingdf(whichdef, total)
            else:
                startorder()

    else:
        if whichdef == "crust":
            crustdf(total)
        elif whichdef == "size":
            sizedf(total)
        elif whichdef == "base":
            basedf(total)
        elif whichdef == "toppings":
            toppingdf(whichdef, total)
        else:
            startorder()


def crustdf(total):
    whichdef = "crust"
    print("\nCrust:")
    printArray(crust)
    userCrust = input("Which type of crust would you like(type the number): ")
    validate(userCrust, whichdef, crust, total)
    userCrust = crust[int(userCrust)-1]
    print("You chose " + userCrust)
    check = input("Is that your choice? Yes or No: ").lower()
    if check == "yes":
        price = money(userCrust)
        total += float(price)
        print("Total: " + format(total, '.2f'))
        order.append(userCrust)
        sizedf(total)
    else:
        crustdf(total)


def sizedf(total):
    whichdef = "size"
    print("\nSize:")
    printArray(size)
    userSize = input("Which size would you like(type the number): ")
    validate(userSize, whichdef, size, total)
    userSize = size[int(userSize) - 1]
    print("You chose " + userSize)
    check = input("Is that your choice? Yes or No: ").lower()
    if check == "yes":
        price = money(userSize)
        total += float(price)
        print("Total: " + format(total, '.2f'))
        order.append(userSize)
        basedf(total)
    else:
        sizedf(total)

def basedf(total):
    whichdef = "base"
    print("\nBase:")
    printArray(base)
    userBase = input("Which base would you like(type the number): ")
    validate(userBase, whichdef, base, total)
    userBase = int(userBase)
    print("You chose " + base[userBase - 1])
    check = input("Is that your choice? Yes or No: ").lower()
    if check == "yes":
        order.append(base[userBase - 1])
        toppingdf(whichdef, total)
    else:
        basedf(total)


def toppingdf(whichdef, total):
    userTopping = []

    def toppingselection(userTopping):
        toppingselect = input("Non-Veg(NV) or Veg(V) or Remove last topping choice(R): ").lower()
        if toppingselect == "nv":
            printArray(nonveg)
            usertoppingselect = input("Select a topping(type the number): ")
            print("Added "+nonveg[int(usertoppingselect)-1])
            userTopping.append(nonveg[int(usertoppingselect) - 1])
            print("Toppings: "+ ", ".join(userTopping))
        elif toppingselect == "v":
            printArray(veg)
            usertoppingselect = input("Select a topping(type the number): ")
            print("Added " + veg[int(usertoppingselect) - 1])
            userTopping.append(veg[int(usertoppingselect) - 1])
            print("Toppings: " + ", ".join(userTopping))
        elif toppingselect == "r":
            userTopping.pop()
            print("Toppings: " + ", ".join(userTopping))
        else:
            toppingselection(userTopping)
    if whichdef == "toppings":
        toppingselection(userTopping)
    whichdef = "toppings"
    print("\nToppings:")
    print("You can select up to six toppings...")
    while len(userTopping) <= 5:
        toppingselection(userTopping)

    check = input("Are those your choices? Yes or No: ").lower()
    if check == "yes":
        print(userTopping)
        order.append(userTopping)
        write(userTopping, total)
    else:
        toppingdf(whichdef, total)


def write(userTopping, total):
    with open("order.txt", mode="w", encoding="utf-8") as my_file:
        for item in order:
            if item == userTopping:
                my_file.write(str(", ". join(userTopping)))
            else:
                my_file.write(item + "\n")

    print("Your total: " + format(total, '.2f'))
    print("Thank You for ordering at Pizza Shop.")


def startorder():
    whichdef = ""
    total = 0
    print("Welcome to Pizza Shop!\nNote: When placing order; type the number of the option not the name.")
    start = input("Start your order? Yes or No: ").lower()
    if start == "yes":
        crustdf(total)
    else:
        startorder()


def main():
    check = input("View Order(v) or New Order(n): ").lower()
    if check == "v":
        print("\n")
        with open("order.txt", mode="r", encoding="utf-8") as my_order:
            for item in my_order:
                print(item)
        print("\n")
    if check == "n":
        startorder()

while True:
    main()
