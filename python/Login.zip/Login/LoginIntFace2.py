import subprocess
user_database = open("database.txt", mode="r", encoding="utf-8")
questions_list = ["Your pet's name? ", "Your first school? ", "Your best friend's name? ", "What is your mother's maiden name? ",
                  "Who is your favorite actor, musician, or artist? ", "What is your favorite movie? ",
                  "What is your favorite color? ", "In what city were you born? "]


def main():
    global database_list
    database_list = user_database.readlines()
    print(database_list)
    stringseparator(database_list)
    print(database_list)
    choice = input("1 for new user\n2 for login\n")
    if choice == "1":
        newuser()

    elif choice == "2":
        login()

    elif choice == "3":
        forgot_password()
    else:
        main()

"""
def file_len(full_path):
    f = open(full_path)
    nr_of_lines = sum(1 for line in f)
    f.close()
    return nr_of_lines
"""

def forgot_password():
    global poser

    username = input("Username: ")
    for i in range(0, len(database_list)):

        if username == database_list[i][0]:
            poser = i

    question_for_user = (database_list[poser][5] +","+ database_list[poser][6] +","+ database_list[poser][7]).split(",")
    print(question_for_user)
    user_questions = []
    for i in range(0, 3):
        user_questions.append(questions_list[int(question_for_user[i])-1])

    count = 0
    for i in user_questions:
        count += 1
        print(str(count) + ") " + i)

    choice = input("Select the question number you would like to attend.")

    print("...")
    print(user_questions[int(choice)-1])

    answer = input("Answer: ")

    pos = database_list[poser].index(question_for_user[int(choice) - 1]) + 3
    real_answer = database_list[poser][pos]
    if answer == real_answer:
        change_password(poser)
    else:
        print("Wrong Answer!!!")
        main()




def checkexists(string, which, array):
    returns = "False"
    for i in range(0, len(array)):

        if string == database_list[i][which]:
            returns = "True"
    return returns


def password_exists(password, username, array):
    returns = "False"
    for i in range(0, len(array)):

        if username == database_list[i][0]:
            number = i

            if password == database_list[number][1]:
                returns = "True"

    return returns

def writestatement():
    with open("database.txt", "w+") as f:
        with open("database.txt", "a+") as f:
            for item in database_list:
                newarray = []
                for i in database_list[database_list.index(item)]:
                    newarray.append(i)
                record = ",".join(newarray)
                f.write(record)

def change_password(pos):
    newpassword = input("New Password: ")
    choice = input("Change password to " + newpassword + "(Y/N): ").lower()
    if choice == "y":
        database_list[pos].pop(1)
        database_list[pos].insert(1, newpassword)
        writestatement()

    else:
        change_password(pos)


def login():
    username = input("Username: ")
    if checkexists(username, 0, database_list) == "True":
        password = input("Password: ")
        if password_exists(password,username,database_list) == "True":
            print("Account found!!!!")
        else:
            print("Password not matched")
            login()

    else:
        print("Username not found")
        login()


def newuser():
    new_array = []
    n = 1
    print("DO NOT INCLUDE COMMAS(,)")

    def validate(choice):
        if choice.isdigit():
            if len(questions_list) >= int(choice) >= 1:
                return choice
            else:
                questionsdef(n)

    def usernamedef():
        username = input("Username(20 chars only): ")
        if checkexists(username, 0, database_list) == "False" and len(username) <= 20:
            new_array.append(username)
            passworddef()
        else:
            print("Username not available:")
            usernamedef()


    def passworddef():
        password = input("Password(20 chars only): ")
        if len(password) > 20:
            passworddef()
        else:
            new_array.append(password)

    def questionsdef(n):
        userques = []
        userans = []
        print("Select three security questions from the list below:")
        count = 0
        for i in questions_list:
            count += 1
            print(str(count) + ") " + i)
        while n <= 3:
            qchoice = input("Choice number "+str(n)+": ")
            validate(qchoice)
            userques.append(qchoice)
            answer = input("Your answer: ")
            userans.append(answer)
            n += 1
        userques = ",".join(userques)
        userans = ",".join(userans)
        userchoiceques = userques + "," + userans
        return userchoiceques


    usernamedef()
    new_array.append(input("Firstname: "))
    new_array.append(input("Surname: "))
    new_array.append(input("Date of Birth(DD/MM/YY): "))
    new_array.append(questionsdef(n) + "\n")
    record = ",".join(new_array)
    with open("database.txt", 'a') as f:
        f.write(record)


def stringseparator(array):
    for i in array:
        pos = array.index(i)
        new_array = i
        new_array = new_array.split(",")
        array[pos] = new_array



main()
