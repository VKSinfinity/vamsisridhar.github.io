import turtle
import random
import sys
from itertools import repeat
open('Input_data.txt', 'w').close()
counter=0
mistakes=0
mistakes2=0
mscn=0
guess2=""
#m=int(l)
r=random.randint(1,15)
word=["frog","mouse","krypton","superman","chocolate","batman","joker","fish",
      "porter","luck","cyclops","boxer","robin","martian","dragon"]
clues=["It is an amphibian","It likes cheese","A fictional sci-fi planet","He can fly","It is a sweet",
       "He is part of the Justice League","A deck of cards has only 2-3 of them",
       "They live in water","Person who carries your bags","A four leafed weed gives you this",
       "A one eyed giant","It is a breed of dog","It is a bird","He lives on mars","it breathes fire"]
cluescnt=clues[r]
w = word[r]
n = ["_ "]
l=len(w)
global dis
dis = [x for item in n for x in repeat(item, l)]
mscn2=dis.count("_ ")
#print(''.join(dis))

def intro():
    global l
    global guess
    l=len(w)
    print("The word is "+str(l)+" long.")
    global cluescnt
    print("The clue is: "+str(cluescnt)+".")
    guess = input("Enter a letter: ")
    check()

def end():
    global w
    global counter
    global mistakes
    print("YOU DIED!!!")
    print("The word was: "+w)
    print("Guesses taken: "+str(counter))
    print("Mistakes: "+str(mistakes))
    sys.exit()
    
    
    
def check():
    global guess
    global l
    global w
    global dis
    global n
    global counter
    global mistakes
    global mistakes2
    global mscn
    global mscn2
    global guess2
    if len(guess)>1:
        print("Enter ONE letter only!")
        intro()
    else:
        
        for i in range(0,l):
            if guess==w[i]:
                dis[i]=guess
            else:
                if dis[i]=="_ ":
                    dis[i]="_ "
           # print(w[i]+str(i))
           
            mistakescounter=dis.count("_ ")
            mscn=[0]

                
            mscn.append(mistakescounter)
            ml=len(mscn)
            ma=mscn[(ml-1)]
            
    # Decrypting the text file
        with open('Input_data.txt', 'r') as myfile:
            data=myfile.read().replace('\n', '')
            
        data_var=list(data)

        data_length=len(data_var)

       # for data_cnt in range(0,data_length):
      #      if data_var[data_cnt]==guess:
        #        print("You have already entered this letter.")
         #       break

        if guess in data_var:
            print("You have already entered this letter.")
            intro()
        else:
            counter=counter+1
            if mscn2==mscn:
                mistakes=mistakes+1
        
        #if guess2!=guess:
            #if mscn2==mscn:
             #   mistakes=mistakes+1
            
  #      if mistakescounter==m:
   #         mistakes=mistakes+1



#Here is the code fr the turtle program

        if mistakes2!=mistakes:
            if mistakes==1:
                turtle.right(90)
                turtle.penup()
                turtle.forward(100)
                turtle.pendown()
                turtle.right(90)
                turtle.forward(200)
                turtle.right(90)
            elif mistakes==2:
                turtle.forward(300)
                turtle.right(90)
            elif mistakes==3:
                turtle.forward(100)
                turtle.right(90)
            elif mistakes==4:
                turtle.forward(20)
            elif mistakes==5:
                turtle.speed(0)
                turtle.pencolor("red")
                turtle.left(90)
                n=0
                while n<=540:
                    turtle.forward(0.5)
                    turtle.right(1)
                    n=n+1
            elif mistakes==6:
                turtle.pencolor("red")
                turtle.left(90)
                turtle.forward(50)
                turtle.backward(25)
            elif mistakes==7:
                turtle.pencolor("red")
                turtle.right(135)
                turtle.forward(25)
                turtle.backward(25)
                turtle.left(135)
            elif mistakes==8:
                turtle.pencolor("red")
                turtle.left(135)
                turtle.forward(25)
                turtle.backward(25)
                turtle.right(135)
            elif mistakes==9:
                turtle.pencolor("red")
                turtle.forward(25)
                turtle.right(30)
                turtle.forward(25)
                turtle.backward(25)
                turtle.left(60)
            elif mistakes==10:
                turtle.pencolor("red")
                turtle.forward(25)
            
        if mistakes==10:
            end()

        # Translating the text file    
        text_file = open("Input_data.txt", "a")

        text_file.write(guess+"\n")

        text_file.close()

        if len(data)==0:
            Used_letters="None"
        else:
            Used_letters=','.join(data)

        # Text after each round
        
        print("The words you have used are: "+Used_letters)
        print(''.join(dis))
        print("Guesses taken: "+str(counter))
        print("Mistakes: "+str(mistakes))
        #print(ma)
        #print(mscn)
        #print(mscn2)
        #print(guess2)
        mscn2=mscn
        guess2=guess
        mistakes2=mistakes
        countitem=dis.count("_ ")
        if countitem!=0:
        #    m=m+1
            intro()
        else:
            print("Congratulations!!!")
            print("You Won in "+str(counter)+" guesses with "+str(mistakes)+" mistakes!")
        
intro()


